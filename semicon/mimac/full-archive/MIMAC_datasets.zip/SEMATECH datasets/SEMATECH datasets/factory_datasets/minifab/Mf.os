PO1            PRODUCTION_OP#1           1   60 MIN BREAK             360.00         60.00      60 MIN TRAINING/MEETING  720.00        60.00
PO2            PRODUCTION_OP#2           1   60 MIN BREAK             360.00         60.00      60 MIN TRAINING/MEETING  720.00        60.00
MT1            MAINTENANCE TECH          1   45 MIN BREAK             360.00         45.00      30 MIN TRAINING/MEETING  720.00        30.00
